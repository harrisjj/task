<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Employee;
use App\Employeehistory;

class SetEmpHistory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'empwebhistory:SET empwebhistory {ip} {url}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Set EmployeeWebHistory ip address and url';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $ip = $this->argument('ip');
        $url = $this->argument('url');
        $employee = Employee::where('ip_address', $ip)->first(); 
        if($employee == null){
            $this->error("IP Address not found"); 
        }else{
            $data = [
                'emp_id' => $employee->emp_id,
                'ip_address' => $ip,
                'url' => $url
            ];
            Employeehistory::create($data);
            $this->info("Web history details added successfully.");
        }
    }
}
