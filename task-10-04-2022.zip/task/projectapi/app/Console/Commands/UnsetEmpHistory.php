<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Employee;
use App\Employeehistory;

class UnsetEmpHistory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'empwebhistory:UNSET empwebhistory {ip}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Unset EmployeeWebHistory based on ip address';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
         $ip_address = $this->argument('ip');
        $res = Employeehistory::where('ip_address',$ip_address)->delete();
        if($res){
            $this->error("Record Deleted Successfully");
        }
    }
}
