<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Employee;
use App\Employeehistory;

class GetEmpHistory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'empwebhistory:GET empwebhistory {ip}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get Employee web history by ip address';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       $ip = $this->argument('ip');
        $employee = Employee::where('ip_address', $ip)->first(); 
        if($employee == null){
            $this->error("Record not exist");  
        }else{

            $data = [
                'id' => $employee->emp_id,
                'ip_address' => $ip,
                'urls' => Employeehistory::where('ip_address', $ip)->select('url','id')->get()
            ];
            echo json_encode($data);
        }
    }
}

{"emp_id":2,"ip_address":"191.78.1.2","urls":[{"url":"https:\/\/google.com","id":2},{"url":"https:\/\/google.com","id":3}]}
